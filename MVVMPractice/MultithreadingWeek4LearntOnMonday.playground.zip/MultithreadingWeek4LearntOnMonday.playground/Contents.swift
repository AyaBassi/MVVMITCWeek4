import UIKit

//3.In Playground show usage of following things by taking different examples of your choice
//a. GCD
//b. Main thread
//c. Global queue
//d. Custom queue
//
//4. Serial queue async and sync
//5 concurrent queue async and sync
//Extra Points for displaying use of GCD for API call

// Multithreading
// 1 GCD - Grand Central Dispatch
// 2 Operation and operation queues
// 3 Swift Concurancy - 13.0 Await - Async
// 4 NSThread/Thread
// 5 DispatchQueues
// 6 PerformSelector
// 7 Libraries - Combine
// Third Party - PromiseKit - RXSwift, Async DisplayKit


// 1.1 GCD FIFO, First In First Out
// Tasks are added in to Queue and GCD picks the oldest task and execute it first

// 3 Types of Queue
// 1. Main Queue - anything related to UI


// 2. Serial Queues or custom Queues

let serialQueue = DispatchQueue(label: "com.multiThreade.serialQueue")
serialQueue.async {
    print("Serial Task Starting...")
    for i in "HHHHH"{
        print(i)
    }
    print("Serial Task Ending...")
}

serialQueue.async {
    print("Serial Task Starting...")
    for i in "GGGGGG"{
        print(i)
    }
    print("Serial Task Ending...")
}


let customQueue = DispatchQueue(label: "com.multithread.customQueue", attributes: .concurrent)

customQueue.async {
    print("Custom Concurrent Task 1 Starting...")
    for i in "111111"{
        print(i)
    }
    print("Custom Concurrent Task 1 Ending...")
}

customQueue.async {
    print("Custom Concurrent Task 2 Starting...")
    for i in "222222"{
        print(i)
    }
    print("Custom Concurrent Task 2 Ending...")
}


let customNonConcurrent = DispatchQueue(label: "com.m.nonConcurrent", attributes: .concurrent)

customNonConcurrent.sync {
    print("Custom non-Concurrent Task 1 Starting...")
    for i in "111111"{
        print(i)
    }
    print("Custom non-Concurrent Task 1 Ending...")
}

customNonConcurrent.sync {
    print("Custom non-Concurrent Task 2 Starting...")
    for i in "2222222"{
        print(i)
    }
    print("Custom non-Concurrent Task 2 Ending...")
}



// 3. Global Queues










DispatchQueue.main.async {
    print("Is GCD a FIFO or LIFO?")
}

DispatchQueue.main.asyncAfter(deadline:.now() + 4) { print("LIFO")}

DispatchQueue.main.asyncAfter(deadline:.now() + 8) {print("DispatchQueue is mainly used for what?")}
DispatchQueue.main.asyncAfter(deadline:.now() + 12) {
    print("UI")
}

DispatchQueue.main.asyncAfter(deadline:.now() + 16) {print("Name the single parameter for a serial DispatchQueue(_____: )?")}

DispatchQueue.main.asyncAfter(deadline:.now() + 20) {
    print("label")
}

DispatchQueue.main.asyncAfter(deadline:.now() + 24) {print("Which argument name is needs to be given the .concurrent value to  make a concurrent operation?")}

DispatchQueue.main.asyncAfter(deadline:.now() + 28) {
    print(".concurrent")
}

// 2. Serial Queues or custom Queues


// 3. Global Queues


DispatchQueue.global(qos: .background).asyncAfter(deadline:.now() + 32) {
    print("Which enum is used for global DispatchQueue?")
}

DispatchQueue.global(qos: .background).asyncAfter(deadline:.now() + 32) {
    print(".background")
}

